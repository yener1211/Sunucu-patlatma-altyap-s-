

1-Botu kullanmadan önce terminali açıp npm install yaz

2-ayarlar.json dosyasında botSahibiID ye kendi idnizi girin ve token kısmına botun tokenini girin __diğerlerini ellemeyin!__

3-Kodu değiştirmeyin zaten size sunduğumuz komutlar sayesinde !boom ve !spam komutlarını !boomayarla ve !spamayarla ile __değiştirebiliyorsunuz!__

4-__Botu paylaşmayın satmayın !__