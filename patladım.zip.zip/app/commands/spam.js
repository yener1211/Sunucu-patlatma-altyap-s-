const fs = require('fs');
const path = require('path');
const ayarlarPath = path.join(__dirname, '../ayarlar.json');

module.exports = {
    name: 'spam',
    description: 'Belirlenen mesajı belirli sayıda gönderir.',
    execute(message, args) {
        try {
            const ayarlar = JSON.parse(fs.readFileSync(ayarlarPath, 'utf8'));
            const { botSahibiID, spamMesaj, spamMesajSayisi } = ayarlar;

            // Komutu sadece bot sahibi kullanabilir mi kontrol et
            if (message.author.id !== botSahibiID) {
                return message.reply('Bu komutu kullanmak için bot sahibi olmalısınız.');
            }

            for (let i = 0; i < spamMesajSayisi; i++) {
                message.channel.send(spamMesaj);
            }

            // Kullanıcının !spam komutunu sil
            setTimeout(() => {
                message.delete()
                    .catch(err => console.log('Komut silinemedi:', err));
            }, 1000);
        } catch (error) {
            console.error('Hata oluştu:', error);
            message.reply('Bir hata oluştu, mesaj gönderilemedi.');
        }
    },
};
